exports.hostName =  '0.0.0.0';
exports.apiKey =    'B2125B8AE6D24507952E64B8A8366D73';
exports.port =      5000;
exports.user = 2;
exports.printer = 17;
