const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');

const ws = new WebSocket('ws://127.0.0.1:8081');

ws.on('open', function open() {
    var filePath = "D:\\Google Drive\\Programming\\node.js\\Clinte\\app.js";

//configuring parameters
    var params = {
        Bucket: 'gcodes',
        Body : fs.createReadStream(filePath),
    };
    ws.send(JSON.stringify(params));

});

ws.on('message', function incoming(data) {
    console.log(data);
});