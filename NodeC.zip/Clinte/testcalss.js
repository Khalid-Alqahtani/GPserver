/*const path = require('path');
var config = require('./config');

Path = "/home/pi/Desktop/test.gode";
let Printer = require('./Printer.js');
Printer.printerState(function (response) {

    response["request"]="update";
    console.log(JSON.stringify(response));
});*/
const AWS = require('aws-sdk');
const fs = require('fs');
const path = require('path');

//const { exec } = require('child_process');
var cmd = require('node-cmd');
var exec = require('child_process').exec;
const spawn = require('child_process').spawn;
const processExists = require('process-exists');
const find = require('find-process');
var ps = require('ps-node');
processExists("ffmpeg").then(exists => {
    if (exists == true) {
        find('name', 'ffmpeg', false)
            .then(function (list) {

                ps.kill( list[0].pid, function( err ) {
                    if (err) {
                        throw new Error( err );
                    }
                    else {
                        console.log( 'ffmpeg has been killed!');
                    }
                });

            });
    }

});

/*execute(command,function (stdout) {
    console.log(stdout);
});
function execute(command, callback) {
    exec(command, function (error, stdout, stderr) {
        console.log(error);
        callback(stdout);
    });
};*/

/*//configuring the AWS environment
    AWS.config.update({
        accessKeyId: "AKIAUVSLBLBHL3HUHEN5",
        secretAccessKey: "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"
    });
    var s3 = new AWS.S3();
    var filePath = "D:\\Google Drive\\Programming\\node.js\\Clinte\\app.js";
//configuring parameters
    var params = {
        Bucket: 'gcodes',
        Body : fs.createReadStream(filePath),
        Key : "folder/"+Date.now()+"_"+path.basename(filePath),
        ACL: 'public-read'
    };
    s3.upload(params, function (err, data) {
        //handle error
        if (err) {
            console.log("Error", err);
        }

        //success
        if (data) {
            console.log("Uploaded in:", data.Location);
        }
    });

*/